package srm.srmexample01;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.MalformedURLException;
import java.net.URL;

import srm.srmlib.SRMClient;
import srm.srmlib.SMSBroadcastReceiver;

public class MainActivity extends AppCompatActivity{
    private static String LOG_TAG = "srm.srmexample01";

    private SRMClient mClient = null;
    private SRMClient mLed = null;
    private SRMClient mButton = null;

    private TextView tvLedState;
    private Button btnLedOn;
    private Button btnLedOff;
    private TextView tvButtonState;
    private Button btnButtonRefresh;

    private URL url;
    private String username;
    private String password;
    private int ledGpio;
    private int buttonGpio;
    private int httpsCheck;
    private boolean verbose;
    private TextView txtView;
    private Spinner spinnerLed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize main layout
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //findViewById(R.id.layout_main).setOnTouchListener(this);

        SMSBroadcastReceiver msg = new SMSBroadcastReceiver();

        //Initialize data
        try {url = new URL("https://p3.srm.bajtahack.si:44300");} catch (MalformedURLException e) {}
        username = "bajtahack";
        password = "srmHekerji";
        ledGpio = 27;
        httpsCheck = SRMClient.HTTPS_BASIC;
        verbose = true;

        txtView = (TextView) findViewById(R.id.TV_Notif);
        btnLedOn = (Button) findViewById(R.id.btn_led_on);
        spinnerLed = (Spinner) findViewById(R.id.spinner);
        /**
         * 0 red
         * 1 blue
         * 2 green
         * */
        btnLedOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new LedOn().execute(spinnerLed.getSelectedItemPosition());
            }
        });
        btnLedOff = (Button) findViewById(R.id.btn_led_off);
        /**
         * 0 red
         * 1 blue
         * 2 green
         * */
        btnLedOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new LedOff().execute(spinnerLed.getSelectedItemPosition());
            }
        });

        /*
        // Initialize Button component
        View.OnClickListener buttonListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new ButtonTask().execute(view.getId());
            }
        };*/

        // Initial state
        setAllButtonsEnabled(false);  // disable all buttons
        new SetupTask().execute();
    }

    /*
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        // Hide virtual keyboard on touch outside of text fields
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        return false;
    }*/

    /** Abstract handler for tasks. */
    private abstract class HandlerTask extends AsyncTask<Integer, Void, Boolean> {
        String data;
        Exception exception;

        @Override
        protected void onPreExecute() {
            this.data = getString(R.string.state_unknown);
            this.exception = null;
            setAllButtonsEnabled(false);  // disable all buttons
            String message = "Executing action...";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        }

        @Override
        protected void onPostExecute(Boolean done) {
            if (done) {  // completed successfully
                setAllButtonsEnabled(true);  // enable all buttons again

            } else {  // something went wrong
                String message = "Something went wrong!\n" + String.valueOf(this.exception);
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

    private class SetupTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String data;
            try {
                Log.d(LOG_TAG, "Initialize...");

                // Create SRM manager
                URL urlx = SRMClient.urlBuilder(url, null, username, password, null, null, null, null, null);
                mClient = new SRMClient(urlx, httpsCheck, null, null, null, verbose);

                // Reset configuration just in case
                mClient.reboot(true);

                // Initialize LED light controller
                ledGpio = 27;
                Log.d(LOG_TAG, "Initialize LED light controller...");
                mClient.post("/phy/gpio/alloc", String.valueOf(ledGpio));
                data = "{\"dir\": \"out\", \"mode\": \"floating\", \"irq\": \"none\", \"debouncing\": 0}";
                mClient.put(String.format("/phy/gpio/%d/cfg/value", ledGpio), data);


                ledGpio = 17;
                mClient.post("/phy/gpio/alloc", String.valueOf(ledGpio));
                data = "{\"dir\": \"out\", \"mode\": \"floating\", \"irq\": \"none\", \"debouncing\": 0}";
                mClient.put(String.format("/phy/gpio/%d/cfg/value", ledGpio), data);


                ledGpio = 26;
                mClient.post("/phy/gpio/alloc", String.valueOf(ledGpio));
                data = "{\"dir\": \"out\", \"mode\": \"floating\", \"irq\": \"none\", \"debouncing\": 0}";
                mClient.put(String.format("/phy/gpio/%d/cfg/value", ledGpio), data);

                //ledUrl = SRMClient.urlBuilder(urlx, null, username, password, null, null, String.format("/phy/gpio/%d/value", ledGpio), null, null);
                //mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);

                /* Initialize button controller
                Log.d(LOG_TAG, "Initialize button controller...");
                mClient.post("/phy/gpio/alloc", String.valueOf(buttonGpio));
                data = "{\"dir\": \"in\", \"mode\": \"floating\", \"irq\": \"none\", \"debouncing\": 0}";
                mClient.put(String.format("/phy/gpio/%d/cfg/value", buttonGpio), data);

                URL buttonUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", buttonGpio), null, null);
                mButton = new SRMClient(buttonUrl, httpsCheck, null, null, null, verbose);

                // Initialize buzzer controller
                Log.d(LOG_TAG, "Initialize buzzer controller...");
                mClient.post("/phy/pwm/alloc", String.valueOf(buzzerPwm));
                data = String.format("{\"mode\": \"pulsewidth\", \"period\": \"%d\"}", buzzerPeriod);
                mClient.put(String.format("/phy/pwm/%d/cfg/value", buzzerPwm), data);

                URL buzzerUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/pwm/%d/value", buzzerPwm), null, null);
                mBuzzer = new SRMClient(buzzerUrl, httpsCheck, null, null, null, verbose);*/

                Handler mainHandler = new Handler(Looper.getMainLooper());
                Runnable myRunnable = new Runnable() {
                    @Override
                    public void run() {
                        setAllButtonsEnabled(true);
                    }
                };
                mainHandler.post(myRunnable);


            } catch (Exception e) {
                Log.e(LOG_TAG, "Exception: " + e.toString(), e);
                return false;
            }
            return true;
        }

    }

    /** Handle tasks for Led component. */
    private class LedOn extends HandlerTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(Integer... viewIds) {
            try {
                URL ledUrl;
                Log.d(LOG_TAG, "Turn LED light on...");
                this.data = "1";

                if(viewIds[0] == 0) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 27), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 1) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 17), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 2) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 26), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
            }
            catch (Exception e){
                e.printStackTrace();
                return false;
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean done) {
            super.onPostExecute(done);
        }
    }

    private class LedOff extends HandlerTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(Integer... viewIds) {
            try {
                URL ledUrl;
                Log.d(LOG_TAG, "Turn LED light off...");
                this.data = "0";

                if(viewIds[0] == 0) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 27), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 1) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 17), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 2) {
                    ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 26), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
            }
            catch (Exception e){
                e.printStackTrace();
                return false;
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean done) {
            super.onPostExecute(done);
        }
    }

    /** Handle tasks for Button component. */
    private class ButtonTask extends HandlerTask {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            tvButtonState.setText(this.data);  // set unknown state
        }

        @Override
        protected Boolean doInBackground(Integer... viewIds) {
            try {
                Log.d(LOG_TAG, "Turn LED light on...");
                this.data = "0";
                /*
                if(viewIds[0] == 0) {
                    URL ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 27), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 1) {
                    URL ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 17), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }
                else if(viewIds[0] == 2) {
                    URL ledUrl = SRMClient.urlBuilder(url, null, username, password, null, null, String.format("/phy/gpio/%d/value", 26), null, null);
                    mLed = new SRMClient(ledUrl, httpsCheck, null, null, null, verbose);
                    mLed.put(null, this.data);
                }*/
            }
            catch (Exception e){
                e.printStackTrace();
                return false;
            }

            return true;
        }

        @Override
        protected void onPostExecute(Boolean done) {
            super.onPostExecute(done);
            tvButtonState.setText(this.data.trim());  // set new state
        }
    }

    private void setAllButtonsEnabled(boolean enabled) {
        //btnSetupInit.setEnabled(enabled);
        //btnSetupReboot.setEnabled(enabled);
        btnLedOn.setEnabled(enabled);
        btnLedOff.setEnabled(enabled);
        /*btnButtonRefresh.setEnabled(enabled);
        btnBuzzerOn.setEnabled(enabled);
        btnBuzzerOff.setEnabled(enabled);*/
    }
}