package srm.srmlib;

/** Private CA certificate for SRMClient. */
public class CaCertPem {
    public static String certPem = "___PLACEHOLDER_FOR_YOUR_PRIVATE_CA_CERTIFICATE___";  // TODO
}
