package srm.srmlib;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import srm.srmexample01.MainActivity;

/**
 * Created by Luka Kadunc on 26. 11. 2017.
 */

public class SMSBroadcastReceiver extends BroadcastReceiver {

    private static final String SMS_RECEIVED = "srm.srmlib.SMSBroadcastReceiver.SMS_RECEIVED";
    private static final String TAG_M = "SMSBroadcastReceiver";
    private static final String TAG_C = "CallBroadcastReceiver";

    private static boolean ring=false;
    private static boolean callReceived=false;
    private String callerPhoneNumber;
    private Context saveContext;

    @Override
    public void onReceive(Context mContext, Intent intent)
    {
        if (intent.getAction().equals(SMS_RECEIVED)) {
            Log.i(TAG_M, "Mesič pršu");
        }
        else {
            saveContext = mContext;
            // Get the current Phone State

            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

            if (state == null) {
                return;
            }

            // If phone state "Rininging"
            if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                ring = true;
                // Get the Caller's Phone Number
                Log.i(TAG_C, "ringing");
            }


            // If incoming call is received
            if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                callReceived = true;
                Log.i(TAG_C, "received");
            }

            // If phone is Idle
            if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                // If phone was ringing(ring=true) and not received(callReceived=false) , then it is a missed call
                if (ring && !callReceived) {
                    Toast.makeText(mContext, "missed call : ", Toast.LENGTH_LONG).show();
                    //workingWithFunctions();
                    ring = false;
                    Log.i(TAG_C, "missed");
                }
                callReceived = false;
            }
        }
    }

    /*@Override
    public void onReceive(Context context, Intent intent) {
        Log.i(TAG, "****************************Intent recieved: " + intent.getAction());
            if (intent.getAction() == SMS_RECEIVED) {
                Bundle bundle = intent.getExtras();
                if (bundle != null) {
                    Object[] pdus = (Object[])bundle.get("pdus");
                    final SmsMessage[] messages = new SmsMessage[pdus.length];
                    for (int i = 0; i < pdus.length; i++) {
                        messages[i] = SmsMessage.createFromPdu((byte[])pdus[i]);
                    }
                    if (messages.length > -1) {
                        Log.i(TAG, "Message recieved: " + messages[0].getMessageBody());
                    }
                }
            }
    }*/
}

